/* =========================================================
   MANSUROV MEBEL — SOZLAMALAR VA MAHSULOTLAR
   Narx, telefon, manzil va mahsulotlarni shu yerda o'zgartiring.
   ========================================================= */

const CONFIG = {
  // Telefon: href uchun (bo'shliqsiz) va ekranda ko'rinadigan ko'rinishi
  phone: "+998900000000",
  phoneDisplay: "+998 90 000 00 00",
  telegram: "mansurov_mebel",          // @ belgisisiz
  instagram: "mansurov_mebel",         // @ belgisisiz
  address: {
    uz: "Shahar, ko'cha nomi, uy raqami",
    ru: "Город, название улицы, номер дома"
  },
  hours: {
    uz: "Har kuni, 09:00 – 20:00",
    ru: "Ежедневно, 09:00 – 20:00"
  },
  // Buyurtmalar yuboriladigan server manzili (POST, JSON).
  // Bo'sh qolsa, buyurtma faqat brauzerda saqlanadi (demo rejim).
  orderEndpoint: ""
};

const CATEGORIES = {
  sofas:    { uz: "Divanlar",            ru: "Диваны" },
  beds:     { uz: "Karavot va matraslar", ru: "Кровати и матрасы" },
  national: { uz: "Milliy mebel",        ru: "Национальная мебель" },
  puf:      { uz: "Pufiklar",            ru: "Пуфы" }
};

const PRODUCTS = [
  {
    id: 1, category: "sofas", price: 4800000, badge: "hit",
    images: ["images/products/yashil-korduroy-divan.jpg"],
    name: { uz: "Yashil korduroy modulli divan", ru: "Зелёный модульный диван из вельвета" },
    material: { uz: "Korduroy (yirik velvet)", ru: "Вельвет (крупный рубчик)" },
    desc: {
      uz: "Zumrad-yashil korduroy matoli yumshoq modulli divan. Modullar ajraladi va bir zumda yotoq joyiga aylanadi.",
      ru: "Мягкий модульный диван из изумрудного вельвета. Модули разбираются и быстро превращаются в спальное место."
    }
  },
  {
    id: 2, category: "sofas", price: 7500000, badge: "new",
    images: ["images/products/qora-burchak-divan.jpg"],
    name: { uz: "Qora burchakli korduroy divan", ru: "Чёрный угловой диван из вельвета" },
    material: { uz: "Korduroy (yirik velvet)", ru: "Вельвет (крупный рубчик)" },
    desc: {
      uz: "Keng burchakli modulli divan, qo'shimcha yumshoq yostiqchalar bilan. Katta oila va mehmonxona uchun.",
      ru: "Просторный угловой модульный диван с дополнительными мягкими подушками. Для большой семьи и гостиной."
    }
  },
  {
    id: 3, category: "sofas", price: 4200000,
    images: ["images/products/xantal-korduroy-divan.jpg"],
    name: { uz: "Xantal rangli korduroy divan", ru: "Горчичный вельветовый диван" },
    material: { uz: "Korduroy", ru: "Вельвет" },
    desc: {
      uz: "Iliq xantal-jigarrang tusdagi ikki kishilik modulli divan. Har qanday interyerga shinamlik qo'shadi.",
      ru: "Двухместный модульный диван тёплого горчично-коричневого оттенка. Добавит уюта любому интерьеру."
    }
  },
  {
    id: 4, category: "beds", price: 6800000,
    images: ["images/products/kulrang-lux-karavot.jpg"],
    name: { uz: "Kulrang karavot + Lux Matras", ru: "Серая кровать + Lux Matras" },
    material: { uz: "Korduroy, ortopedik matras", ru: "Вельвет, ортопедический матрас" },
    desc: {
      uz: "Kulrang korduroy bosh qismli karavot va Lux Matras ortopedik matrasi to'plami. Sog'lom va qulay uyqu uchun.",
      ru: "Комплект: кровать с серым вельветовым изголовьем и ортопедический матрас Lux Matras. Для здорового и комфортного сна."
    }
  },
  {
    id: 5, category: "sofas", price: 5400000, badge: "hit",
    images: ["images/products/kulrang-shezlong-divan.jpg"],
    name: { uz: "Och kulrang shezlongli divan", ru: "Светло-серый диван с шезлонгом" },
    material: { uz: "Korduroy (yirik velvet)", ru: "Вельвет (крупный рубчик)" },
    desc: {
      uz: "Shezlongli qulay burchak divan, dekorativ yostiqchalar bilan. Zamonaviy mehmonxona uchun ideal.",
      ru: "Удобный угловой диван с шезлонгом и декоративными подушками. Идеален для современной гостиной."
    }
  },
  {
    id: 6, category: "national", price: 5900000,
    images: ["images/products/milliy-toplam.jpg"],
    name: { uz: "Milliy uslubdagi o'tirish to'plami", ru: "Комплект для сидения в национальном стиле" },
    material: { uz: "Milliy naqshli gobelen mato", ru: "Гобелен с национальным орнаментом" },
    desc: {
      uz: "Milliy naqshli ko'rpachalar, suyanchiqlar, gilam va pufikdan iborat to'plam. Mehmon kutish uchun an'anaviy shinamlik.",
      ru: "Комплект из курпачей, спинок, ковра и пуфа с национальным орнаментом. Традиционный уют для приёма гостей."
    }
  },
  {
    id: 7, category: "sofas", price: 4600000,
    images: ["images/products/qora-korduroy-divan.jpg"],
    name: { uz: "To'q jigarrang korduroy divan", ru: "Тёмно-коричневый вельветовый диван" },
    material: { uz: "Korduroy (yirik velvet)", ru: "Вельвет (крупный рубчик)" },
    desc: {
      uz: "To'q tusli premium korduroy matoli modulli divan. Amaliy, dog'ga chidamli va juda yumshoq.",
      ru: "Модульный диван из премиального вельвета тёмного оттенка. Практичный, немаркий и очень мягкий."
    }
  },
  {
    id: 8, category: "beds", price: 7200000, badge: "new",
    images: ["images/products/qora-romb-karavot.jpg"],
    name: { uz: "Romb boshlikli karavot + Lux Matras", ru: "Кровать с ромбовым изголовьем + Lux Matras" },
    material: { uz: "Velur, ortopedik matras", ru: "Велюр, ортопедический матрас" },
    desc: {
      uz: "Romb naqshli velur boshlikka ega qora karavot va Lux Matras ortopedik matrasi to'plami.",
      ru: "Комплект: чёрная кровать с велюровым изголовьем в ромб и ортопедический матрас Lux Matras."
    }
  },
  {
    id: 9, category: "sofas", price: 4100000,
    images: ["images/products/moviy-velvet-divan.jpg", "images/products/moviy-velvet-divan-2.jpg"],
    name: { uz: "Moviy velvet modulli divan", ru: "Голубой модульный диван из велюра" },
    material: { uz: "Velvet (velur)", ru: "Велюр" },
    desc: {
      uz: "Moviy tusli yumshoq velvet matoli transformatsiyalanuvchi modulli divan. Yostiqlar qo'ltiqqa ham, suyanchiqqa ham aylanadi.",
      ru: "Трансформируемый модульный диван из мягкого голубого велюра. Валики служат и подлокотниками, и спинкой."
    }
  },
  {
    id: 10, category: "puf", price: 450000,
    images: ["images/products/bean-bag-puf.jpg"],
    name: { uz: "Bean bag kreslo-pufik", ru: "Кресло-мешок (бинбэг)" },
    material: { uz: "Yumshoq velur", ru: "Мягкий велюр" },
    desc: {
      uz: "Yengil va juda shinam kreslo-pufik. Dam olish burchagi, bolalar xonasi yoki ofis uchun.",
      ru: "Лёгкое и очень уютное кресло-мешок. Для зоны отдыха, детской комнаты или офиса."
    }
  }
];

const SHOWROOM = [
  { src: "images/showroom/dokon-tashqi.jpg", caption: { uz: "Do'konimiz tashqi ko'rinishi", ru: "Вход в наш магазин" }, tall: true },
  { src: "images/showroom/shourum-javonlar.jpg", caption: { uz: "Modulli divanlar ko'rgazmasi", ru: "Экспозиция модульных диванов" } },
  { src: "images/products/milliy-toplam.jpg", caption: { uz: "Milliy mebel burchagi", ru: "Уголок национальной мебели" } },
  { src: "images/products/qora-romb-karavot.jpg", caption: { uz: "Karavot va matraslar zali", ru: "Зал кроватей и матрасов" } },
  { src: "images/products/qora-burchak-divan.jpg", caption: { uz: "Burchakli divanlar", ru: "Угловые диваны" } },
  { src: "images/products/yashil-korduroy-divan.jpg", caption: { uz: "Korduroy kolleksiyasi", ru: "Вельветовая коллекция" } }
];
