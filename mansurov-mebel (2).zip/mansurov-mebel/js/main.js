/* =========================================================
   MANSUROV MEBEL — MAIN SCRIPT
   ========================================================= */
(function () {
  "use strict";

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

  /* ---------- Storage (xavfsiz) ---------- */
  const store = {
    get(key, fallback) {
      try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
      catch (e) { return fallback; }
    },
    set(key, val) {
      try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* ignore */ }
    }
  };

  /* ---------- State ---------- */
  const savedLang = store.get("mm_lang", null);
  const browserRu = (navigator.language || "").toLowerCase().startsWith("ru");
  const state = {
    lang: savedLang || (browserRu ? "ru" : "uz"),
    filter: "all",
    sort: "default",
    cart: store.get("mm_cart", []).filter(i => PRODUCTS.some(p => p.id === i.id)),
    product: null,
    imgIndex: 0,
    qty: 1,
    orderMode: "order",      // "order" | "callback"
    lightbox: { items: [], index: 0 }
  };

  /* ---------- Helpers ---------- */
  const t = (key) => (I18N[state.lang] && I18N[state.lang][key]) ?? I18N.uz[key] ?? key;
  const L = (obj) => (obj ? obj[state.lang] ?? obj.uz : "");
  const fmt = (n) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " " + t("currency");
  const byId = (id) => PRODUCTS.find(p => p.id === id);
  const esc = (s) => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  /* =========================================================
     I18N
     ========================================================= */
  function applyLang() {
    document.documentElement.lang = state.lang;
    document.title = t("meta.title");
    const md = $('meta[name="description"]');
    if (md) md.setAttribute("content", t("meta.desc"));

    $$("[data-i18n]").forEach(el => { el.textContent = t(el.dataset.i18n); });
    $$("[data-i18n-html]").forEach(el => { el.innerHTML = t(el.dataset.i18nHtml); });
    $$("[data-i18n-ph]").forEach(el => { el.placeholder = t(el.dataset.i18nPh); });
    $$("[data-i18n-aria]").forEach(el => { el.setAttribute("aria-label", t(el.dataset.i18nAria)); });

    $$(".lang__btn").forEach(b => {
      const on = b.dataset.lang === state.lang;
      b.classList.toggle("is-active", on);
      b.setAttribute("aria-pressed", on);
    });

    $("#contactAddress").textContent = L(CONFIG.address);
    $("#contactHours").textContent = L(CONFIG.hours);

    renderFilters();
    renderProducts();
    renderGallery();
    renderCart();
    if (state.product) fillProductModal();
    if ($("#orderModal").classList.contains("is-open")) fillOrderModal();
    if ($("#lightbox").classList.contains("is-open")) showLightboxItem();

    store.set("mm_lang", state.lang);
  }

  /* =========================================================
     CONTACT LINKS
     ========================================================= */
  function initContacts() {
    $$(".js-phone-link").forEach(a => { a.href = "tel:" + CONFIG.phone; });
    $$(".js-phone-text").forEach(el => { el.textContent = CONFIG.phoneDisplay; });
    $("#tgLink").href = "https://t.me/" + CONFIG.telegram;
    $("#igLink").href = "https://instagram.com/" + CONFIG.instagram;
    $("#year").textContent = new Date().getFullYear();
  }

  /* =========================================================
     CATALOG
     ========================================================= */
  function renderFilters() {
    const wrap = $("#filters");
    const cats = ["all", ...Object.keys(CATEGORIES)];
    wrap.innerHTML = cats.map(c => {
      const count = c === "all" ? PRODUCTS.length : PRODUCTS.filter(p => p.category === c).length;
      const label = c === "all" ? t("filter.all") : L(CATEGORIES[c]);
      const on = state.filter === c;
      return `<button class="filter${on ? " is-active" : ""}" role="tab" aria-selected="${on}" data-filter="${c}">
                ${esc(label)} <span class="filter__count">${count}</span>
              </button>`;
    }).join("");
  }

  function getVisibleProducts() {
    let list = state.filter === "all" ? PRODUCTS.slice() : PRODUCTS.filter(p => p.category === state.filter);
    if (state.sort === "asc") list.sort((a, b) => a.price - b.price);
    if (state.sort === "desc") list.sort((a, b) => b.price - a.price);
    return list;
  }

  function renderProducts() {
    const grid = $("#productGrid");
    const list = getVisibleProducts();
    if (!list.length) {
      grid.innerHTML = `<p class="grid__empty">${esc(t("card.empty"))}</p>`;
      return;
    }
    grid.innerHTML = list.map((p, i) => {
      const badge = p.badge
        ? `<span class="tag ${p.badge === "hit" ? "tag--hot" : "tag--new"}">${esc(t("badge." + p.badge))}</span>`
        : "";
      const photos = p.images.length > 1 ? `<span class="card__photos"><i class="fa-regular fa-images"></i> ${p.images.length}</span>` : "";
      return `
        <article class="card" style="animation-delay:${i * 50}ms">
          <button class="card__media" data-open="${p.id}" aria-label="${esc(L(p.name))}">
            <img src="${p.images[0]}" alt="${esc(L(p.name))}" loading="lazy">
            <span class="card__tags"><span class="tag">${esc(L(CATEGORIES[p.category]))}</span>${badge}</span>
            ${photos}
          </button>
          <div class="card__body">
            <h3 class="card__title">${esc(L(p.name))}</h3>
            <p class="card__desc">${esc(L(p.desc))}</p>
          </div>
          <div class="card__foot">
            <div class="card__price">
              <small>${esc(t("card.price"))}</small>
              <strong>${fmt(p.price)}</strong>
            </div>
            <div class="card__btns">
              <button class="card__more" data-open="${p.id}">${esc(t("card.more"))}</button>
              <button class="card__add" data-add="${p.id}" aria-label="${esc(t("card.add"))}" title="${esc(t("card.add"))}">
                <i class="fa-solid fa-cart-plus"></i>
              </button>
            </div>
          </div>
        </article>`;
    }).join("");
  }

  /* =========================================================
     GALLERY
     ========================================================= */
  function renderGallery() {
    $("#gallery").innerHTML = SHOWROOM.map((g, i) => `
      <figure class="gallery__item" tabindex="0" role="button" data-gallery="${i}" aria-label="${esc(L(g.caption))}">
        <img src="${g.src}" alt="${esc(L(g.caption))}" loading="lazy">
        <figcaption>${esc(L(g.caption))}</figcaption>
      </figure>`).join("");
  }

  /* =========================================================
     MODALS (umumiy)
     ========================================================= */
  const openStack = [];
  let lastFocus = null;

  function openOverlay(id) {
    const el = document.getElementById(id);
    if (!el || el.classList.contains("is-open")) return;
    if (!openStack.length) lastFocus = document.activeElement;
    el.classList.add("is-open");
    el.setAttribute("aria-hidden", "false");
    openStack.push(id);
    document.body.classList.add("no-scroll");
    const focusable = el.querySelector("[data-close]");
    setTimeout(() => focusable && focusable.focus({ preventScroll: true }), 50);
  }

  function closeOverlay(id) {
    const el = document.getElementById(id);
    if (!el || !el.classList.contains("is-open")) return;
    el.classList.remove("is-open");
    el.setAttribute("aria-hidden", "true");
    const i = openStack.indexOf(id);
    if (i > -1) openStack.splice(i, 1);
    if (id === "productModal") state.product = null;
    if (!openStack.length) {
      document.body.classList.remove("no-scroll");
      if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true });
    }
  }

  function initOverlays() {
    $$(".overlay").forEach(ov => {
      ov.addEventListener("click", (e) => {
        if (e.target === ov || e.target.closest("[data-close]")) closeOverlay(ov.id);
      });
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && openStack.length) closeOverlay(openStack[openStack.length - 1]);
      if ($("#lightbox").classList.contains("is-open")) {
        if (e.key === "ArrowRight") stepLightbox(1);
        if (e.key === "ArrowLeft") stepLightbox(-1);
      }
    });
  }

  /* =========================================================
     PRODUCT MODAL
     ========================================================= */
  function openProduct(id) {
    const p = byId(id);
    if (!p) return;
    state.product = p;
    state.imgIndex = 0;
    state.qty = 1;
    fillProductModal();
    openOverlay("productModal");
  }

  function fillProductModal() {
    const p = state.product;
    $("#pmImg").src = p.images[state.imgIndex];
    $("#pmImg").alt = L(p.name);
    $("#pmCat").textContent = L(CATEGORIES[p.category]);
    $("#pmTitle").textContent = L(p.name);
    $("#pmDesc").textContent = L(p.desc);
    $("#pmMaterial").textContent = L(p.material);
    $("#pmPrice").textContent = fmt(p.price);
    $("#pmQty").textContent = state.qty;
    $("#pmThumbs").innerHTML = p.images.length > 1
      ? p.images.map((src, i) => `<button class="pm__thumb${i === state.imgIndex ? " is-active" : ""}" data-thumb="${i}"><img src="${src}" alt=""></button>`).join("")
      : "";
  }

  function initProductModal() {
    $("#pmThumbs").addEventListener("click", (e) => {
      const b = e.target.closest("[data-thumb]");
      if (!b) return;
      state.imgIndex = Number(b.dataset.thumb);
      fillProductModal();
    });
    $("#pmMinus").addEventListener("click", () => { state.qty = Math.max(1, state.qty - 1); $("#pmQty").textContent = state.qty; });
    $("#pmPlus").addEventListener("click", () => { state.qty = Math.min(99, state.qty + 1); $("#pmQty").textContent = state.qty; });
    $("#pmAdd").addEventListener("click", () => {
      addToCart(state.product.id, state.qty);
      closeOverlay("productModal");
      openOverlay("cartDrawer");
    });
    $("#pmBuy").addEventListener("click", () => {
      addToCart(state.product.id, state.qty, true);
      closeOverlay("productModal");
      openOrder("order");
    });
    $("#pmMainBtn").addEventListener("click", () => {
      const p = state.product;
      openLightbox(p.images.map(src => ({ src, caption: p.name })), state.imgIndex);
    });
  }

  /* =========================================================
     LIGHTBOX
     ========================================================= */
  function openLightbox(items, index = 0) {
    state.lightbox = { items, index };
    $("#lightbox .lightbox").classList.toggle("is-single", items.length < 2);
    showLightboxItem();
    openOverlay("lightbox");
  }
  function showLightboxItem() {
    const { items, index } = state.lightbox;
    const it = items[index];
    if (!it) return;
    $("#lbImg").src = it.src;
    $("#lbImg").alt = L(it.caption);
    $("#lbCaption").textContent = L(it.caption);
  }
  function stepLightbox(dir) {
    const lb = state.lightbox;
    if (lb.items.length < 2) return;
    lb.index = (lb.index + dir + lb.items.length) % lb.items.length;
    showLightboxItem();
  }
  function initLightbox() {
    $("#lbPrev").addEventListener("click", () => stepLightbox(-1));
    $("#lbNext").addEventListener("click", () => stepLightbox(1));

    // swipe (mobil)
    let x0 = null;
    const lb = $("#lightbox");
    lb.addEventListener("touchstart", e => { x0 = e.touches[0].clientX; }, { passive: true });
    lb.addEventListener("touchend", e => {
      if (x0 === null) return;
      const dx = e.changedTouches[0].clientX - x0;
      if (Math.abs(dx) > 50) stepLightbox(dx < 0 ? 1 : -1);
      x0 = null;
    });

    const gallery = $("#gallery");
    const openFromGallery = (el) => openLightbox(SHOWROOM.map(g => ({ src: g.src, caption: g.caption })), Number(el.dataset.gallery));
    gallery.addEventListener("click", e => { const el = e.target.closest("[data-gallery]"); if (el) openFromGallery(el); });
    gallery.addEventListener("keydown", e => {
      if ((e.key === "Enter" || e.key === " ") && e.target.matches("[data-gallery]")) { e.preventDefault(); openFromGallery(e.target); }
    });

    $(".hero__media").addEventListener("click", () => {
      openLightbox([{ src: "images/hero.jpg", caption: { uz: I18N.uz["hero.cardTitle"], ru: I18N.ru["hero.cardTitle"] } }]);
    });
  }

  /* =========================================================
     CART
     ========================================================= */
  function saveCart() { store.set("mm_cart", state.cart); }

  function cartCount() { return state.cart.reduce((s, i) => s + i.qty, 0); }
  function cartTotal() { return state.cart.reduce((s, i) => s + (byId(i.id)?.price || 0) * i.qty, 0); }

  function addToCart(id, qty = 1, silent = false) {
    const item = state.cart.find(i => i.id === id);
    if (item) item.qty = Math.min(99, item.qty + qty);
    else state.cart.push({ id, qty });
    saveCart();
    renderCart();
    const badge = $("#cartBadge");
    badge.classList.remove("bump"); void badge.offsetWidth; badge.classList.add("bump");
    if (!silent) showToast(t("toast.added"), L(byId(id).name), "info");
  }

  function changeQty(id, delta) {
    const item = state.cart.find(i => i.id === id);
    if (!item) return;
    item.qty += delta;
    if (item.qty <= 0) state.cart = state.cart.filter(i => i.id !== id);
    else item.qty = Math.min(99, item.qty);
    saveCart();
    renderCart();
  }

  function removeFromCart(id) {
    state.cart = state.cart.filter(i => i.id !== id);
    saveCart();
    renderCart();
  }

  function renderCart() {
    const count = cartCount();
    const badge = $("#cartBadge");
    badge.textContent = count;
    badge.hidden = count === 0;

    const body = $("#cartItems");
    const foot = $("#cartFoot");

    if (!state.cart.length) {
      body.innerHTML = `
        <div class="cart-empty">
          <i class="fa-solid fa-couch"></i>
          <strong>${esc(t("cart.empty"))}</strong>
          <p>${esc(t("cart.emptyHint"))}</p>
          <a href="#catalog" class="btn btn--primary" data-to-catalog>${esc(t("cart.toCatalog"))}</a>
        </div>`;
      foot.hidden = true;
      return;
    }

    foot.hidden = false;
    body.innerHTML = state.cart.map(i => {
      const p = byId(i.id);
      return `
        <div class="ci">
          <img src="${p.images[0]}" alt="">
          <div>
            <div class="ci__name">${esc(L(p.name))}</div>
            <div class="ci__price">${fmt(p.price * i.qty)}</div>
            <div class="qty qty--sm">
              <button class="qty__btn" data-dec="${p.id}" aria-label="−"><i class="fa-solid fa-minus"></i></button>
              <span class="qty__val">${i.qty}</span>
              <button class="qty__btn" data-inc="${p.id}" aria-label="+"><i class="fa-solid fa-plus"></i></button>
            </div>
          </div>
          <button class="ci__remove" data-remove="${p.id}" aria-label="${esc(t("cart.remove"))}" title="${esc(t("cart.remove"))}">
            <i class="fa-solid fa-trash-can"></i>
          </button>
        </div>`;
    }).join("");
    $("#cartTotal").textContent = fmt(cartTotal());
  }

  function initCart() {
    $("#cartBtn").addEventListener("click", () => openOverlay("cartDrawer"));
    $("#cartItems").addEventListener("click", (e) => {
      const inc = e.target.closest("[data-inc]");
      const dec = e.target.closest("[data-dec]");
      const rem = e.target.closest("[data-remove]");
      if (inc) changeQty(Number(inc.dataset.inc), 1);
      if (dec) changeQty(Number(dec.dataset.dec), -1);
      if (rem) removeFromCart(Number(rem.dataset.remove));
      if (e.target.closest("[data-to-catalog]")) closeOverlay("cartDrawer");
    });
    $("#checkoutBtn").addEventListener("click", () => { closeOverlay("cartDrawer"); openOrder("order"); });
    $("#clearCartBtn").addEventListener("click", () => { state.cart = []; saveCart(); renderCart(); });
  }

  /* =========================================================
     ORDER FORM
     ========================================================= */
  function openOrder(mode) {
    state.orderMode = mode === "order" && state.cart.length ? "order" : "callback";
    clearErrors();
    fillOrderModal();
    openOverlay("orderModal");
  }

  function fillOrderModal() {
    const isOrder = state.orderMode === "order";
    $("#orderTitle").textContent = t(isOrder ? "order.title" : "order.titleCall");
    $("#orderSub").textContent = t(isOrder ? "order.sub" : "order.subCall");
    $("#orderSubmitText").textContent = t(isOrder ? "order.submit" : "order.submitCall");
    $("#orderIco").className = isOrder ? "fa-solid fa-box-open" : "fa-solid fa-headset";
    $$(".js-order-only").forEach(el => { el.hidden = !isOrder; });

    if (isOrder) {
      const rows = state.cart.map(i => {
        const p = byId(i.id);
        return `<div class="os__row"><span>${esc(L(p.name))} × ${i.qty}</span><span>${fmt(p.price * i.qty)}</span></div>`;
      }).join("");
      $("#orderSummary").innerHTML = `
        <h4>${esc(t("order.summary"))}</h4>
        ${rows}
        <div class="os__row os__total"><span>${esc(t("cart.total"))}</span><span>${fmt(cartTotal())}</span></div>`;
    } else {
      $("#orderSummary").innerHTML = "";
    }
  }

  // Telefon maskasi: +998 90 123 45 67
  function formatPhone(value) {
    let d = value.replace(/\D/g, "");
    if (d.startsWith("998")) d = d.slice(3);
    d = d.slice(0, 9);
    let out = "+998";
    if (d.length) out += " " + d.slice(0, 2);
    if (d.length > 2) out += " " + d.slice(2, 5);
    if (d.length > 5) out += " " + d.slice(5, 7);
    if (d.length > 7) out += " " + d.slice(7, 9);
    return out;
  }
  const phoneDigits = (v) => { let d = v.replace(/\D/g, ""); if (d.startsWith("998")) d = d.slice(3); return d; };

  function clearErrors() {
    $$("#orderForm .field").forEach(f => f.classList.remove("has-error"));
    $$("#orderForm [data-err]").forEach(e => { e.textContent = ""; });
    $("#formError").hidden = true;
  }
  function setError(name, msg) {
    const err = $(`#orderForm [data-err="${name}"]`);
    err.textContent = msg;
    err.closest(".field").classList.add("has-error");
  }

  function initOrder() {
    const phone = $("#oPhone");
    const caretToEnd = () => { const n = phone.value.length; try { phone.setSelectionRange(n, n); } catch (e) { /* ignore */ } };
    phone.addEventListener("focus", () => {
      if (!phone.value) phone.value = "+998 ";
      setTimeout(caretToEnd, 0);
    });
    phone.addEventListener("blur", () => { if (phone.value.trim() === "+998") phone.value = ""; });
    phone.addEventListener("input", () => { phone.value = formatPhone(phone.value); });

    $$('[data-action="quick-order"]').forEach(b => b.addEventListener("click", (e) => {
      e.preventDefault();
      closeMenu();
      openOrder("order");
    }));
    $$('[data-action="callback"]').forEach(b => b.addEventListener("click", () => openOrder("callback")));

    $("#orderForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      clearErrors();
      const name = $("#oName").value.trim();
      const tel = phoneDigits(phone.value);
      let ok = true;
      if (name.length < 2) { setError("name", t("err.name")); ok = false; }
      if (tel.length !== 9) { setError("phone", t("err.phone")); ok = false; }
      if (!ok) return;

      const isOrder = state.orderMode === "order";
      const order = {
        id: Date.now().toString().slice(-6),
        type: isOrder ? "order" : "callback",
        createdAt: new Date().toISOString(),
        lang: state.lang,
        customer: {
          name,
          phone: "+998" + tel,
          address: isOrder ? $("#oAddress").value.trim() : "",
          comment: $("#oComment").value.trim()
        },
        items: isOrder ? state.cart.map(i => {
          const p = byId(i.id);
          return { id: p.id, name: p.name.uz, qty: i.qty, price: p.price, sum: p.price * i.qty };
        }) : [],
        total: isOrder ? cartTotal() : 0
      };

      const btn = $("#orderSubmit");
      btn.disabled = true;
      $("#orderSubmitText").textContent = t("order.sending");

      try {
        await sendOrder(order);
        const all = store.get("mm_orders", []);
        all.push(order);
        store.set("mm_orders", all);

        if (isOrder) { state.cart = []; saveCart(); renderCart(); }
        $("#orderForm").reset();
        closeOverlay("orderModal");
        if (isOrder) showToast(t("toast.okTitle"), t("toast.okText").replace("{n}", order.id));
        else showToast(t("toast.callTitle"), t("toast.callText"));
      } catch (err) {
        console.error(err);
        const fe = $("#formError");
        fe.textContent = t("err.send") + " " + CONFIG.phoneDisplay;
        fe.hidden = false;
      } finally {
        btn.disabled = false;
        $("#orderSubmitText").textContent = t(isOrder ? "order.submit" : "order.submitCall");
      }
    });
  }

  // Buyurtmani serverga yuborish. CONFIG.orderEndpoint bo'sh bo'lsa — demo rejim.
  async function sendOrder(order) {
    if (!CONFIG.orderEndpoint) {
      console.info("[Mansurov Mebel] Demo rejim — buyurtma brauzerda saqlandi:", order);
      await new Promise(r => setTimeout(r, 600));
      return;
    }
    const res = await fetch(CONFIG.orderEndpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(order)
    });
    if (!res.ok) throw new Error("HTTP " + res.status);
  }

  /* =========================================================
     TOAST
     ========================================================= */
  let toastTimer = null;
  function showToast(title, text = "", type = "success") {
    const el = $("#toast");
    el.classList.toggle("toast--info", type === "info");
    $(".toast__ico", el).className = "toast__ico fa-solid " + (type === "info" ? "fa-cart-plus" : "fa-circle-check");
    $("#toastTitle").textContent = title;
    $("#toastText").textContent = text;
    el.classList.add("is-show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("is-show"), type === "info" ? 2200 : 4500);
  }

  /* =========================================================
     HEADER, MENU, SCROLL
     ========================================================= */
  function closeMenu() {
    $("#nav").classList.remove("is-open");
    const b = $("#burger");
    b.setAttribute("aria-expanded", "false");
    b.querySelector("i").className = "fa-solid fa-bars";
  }

  function initHeader() {
    const header = $("#header");
    const onScroll = () => header.classList.toggle("is-scrolled", window.scrollY > 10);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    $("#burger").addEventListener("click", () => {
      const nav = $("#nav");
      const open = !nav.classList.contains("is-open");
      nav.classList.toggle("is-open", open);
      $("#burger").setAttribute("aria-expanded", String(open));
      $("#burger i").className = open ? "fa-solid fa-xmark" : "fa-solid fa-bars";
    });
    $$(".nav__link").forEach(a => a.addEventListener("click", closeMenu));

    // aktiv bo'limni belgilash
    const links = $$(".nav__link");
    const sections = links.map(a => $(a.getAttribute("href"))).filter(Boolean);
    if ("IntersectionObserver" in window) {
      const io = new IntersectionObserver(entries => {
        entries.forEach(en => {
          if (en.isIntersecting) {
            links.forEach(a => a.classList.toggle("is-active", a.getAttribute("href") === "#" + en.target.id));
          }
        });
      }, { rootMargin: "-45% 0px -50% 0px" });
      sections.forEach(s => io.observe(s));
    }

    $$(".lang__btn").forEach(b => b.addEventListener("click", () => {
      if (b.dataset.lang === state.lang) return;
      state.lang = b.dataset.lang;
      applyLang();
    }));
  }

  function initReveal() {
    const els = $$("[data-reveal]");
    if (!("IntersectionObserver" in window)) { els.forEach(e => e.classList.add("is-in")); return; }
    const io = new IntersectionObserver(entries => {
      entries.forEach(en => {
        if (en.isIntersecting) { en.target.classList.add("is-in"); io.unobserve(en.target); }
      });
    }, { threshold: 0.15 });
    els.forEach((e, i) => { e.style.transitionDelay = (i % 4) * 80 + "ms"; io.observe(e); });
  }

  /* =========================================================
     CATALOG EVENTS
     ========================================================= */
  function initCatalog() {
    $("#filters").addEventListener("click", (e) => {
      const b = e.target.closest("[data-filter]");
      if (!b) return;
      state.filter = b.dataset.filter;
      renderFilters();
      renderProducts();
    });
    $("#sortSelect").addEventListener("change", (e) => {
      state.sort = e.target.value;
      renderProducts();
    });
    $("#productGrid").addEventListener("click", (e) => {
      const add = e.target.closest("[data-add]");
      if (add) { addToCart(Number(add.dataset.add), 1); return; }
      const open = e.target.closest("[data-open]");
      if (open) openProduct(Number(open.dataset.open));
    });
  }

  /* =========================================================
     INIT
     ========================================================= */
  document.addEventListener("DOMContentLoaded", () => {
    initContacts();
    initOverlays();
    initHeader();
    initCatalog();
    initProductModal();
    initLightbox();
    initCart();
    initOrder();
    applyLang();
    initReveal();
  });
})();
