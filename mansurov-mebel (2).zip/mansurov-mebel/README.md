# Mansurov Mebel — sayt

Sof HTML + CSS + JavaScript. Framework, build yoki internet CDN kerak emas — `index.html` ni ochsangiz ishlaydi.

## Tuzilma
```
index.html              — sahifa
css/style.css           — barcha stillar
css/fonts.css           — Manrope + Unbounded (lotin + kirill)
js/data.js              — SOZLAMALAR va MAHSULOTLAR (telefon, manzil, narxlar)
js/i18n.js              — o'zbekcha / ruscha tarjimalar
js/main.js              — katalog, savat, buyurtma, til, modallar
images/                 — logo, hero, mahsulot va shourum rasmlari
fonts/, vendor/         — shriftlar va Font Awesome ikonkalari (lokal)
```

## Nimani o'zgartirish kerak
1. `js/data.js` → `CONFIG`: haqiqiy telefon, Telegram, Instagram, manzil, ish vaqti.
2. `js/data.js` → `PRODUCTS`: narxlar (hozirgilari namunaviy), nom/tavsif.
3. Yangi mahsulot: rasmni `images/products/` ga qo'ying va `PRODUCTS` ga yangi obyekt qo'shing (`uz` va `ru` matnlari bilan).
4. Matnlar: `js/i18n.js` (har bir kalit `uz` va `ru` da bo'lishi kerak).

## Buyurtmalar
`CONFIG.orderEndpoint` bo'sh bo'lsa — demo rejim: buyurtma faqat mijoz brauzerida saqlanadi, sotuvchiga yetib bormaydi.
Haqiqiy ishlatish uchun POST (JSON) qabul qiladigan server manzilini yozing (masalan, buyurtmani Telegram botga uzatadigan kichik backend).
Bot tokenini hech qachon frontend kodiga yozmang.

Yuboriladigan JSON:
```json
{ "id": "123456", "type": "order|callback", "lang": "uz",
  "customer": { "name": "", "phone": "+998901234567", "address": "", "comment": "" },
  "items": [{ "id": 1, "name": "...", "qty": 1, "price": 4800000, "sum": 4800000 }],
  "total": 4800000 }
```
